package oppsConcept;

 class Test {

	 public void m1()
	 {
		 System.out.println("m1");
	 }

	 protected void m2()
	 {
		 System.out.println("m1");
	 }
	 
	  void m3()
	 {
		 System.out.println("m1");
	 }
	 
	 public static void main(String[] args) {
		
		 System.out.println("test");
	}
}
