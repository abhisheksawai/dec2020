package stringDemo;

public class StringCharAT {
	
	public static void main(String[] args) {
		
		
		String name = "Abhishek";
						
	System.out.println(name.charAt(0));
	System.out.println(name.charAt(1));
	System.out.println(name.charAt(2));
	System.out.println(name.charAt(3));
		
		
		
	}

}
