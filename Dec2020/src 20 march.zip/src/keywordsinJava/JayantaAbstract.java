package keywordsinJava;

public abstract class JayantaAbstract extends JayantaAnotherClass{
	
	public abstract void ma();

}
