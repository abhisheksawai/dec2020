package collectionDemo;

public class C extends P{



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		C c1 = new C();
		c1.p1();
		
		
		System.out.println("printn c here ->            "+c1);
		System.out.println("printn c here toString-> "+c1.toString());
		
		
	}

}
