package collectionDemo;

public class WhileloopDemo {
	public static void main(String[] args) {
		
		int x = 10;
		while( x <20)
		{
			System.out.println(x);
			x++;
		}
	}

}
