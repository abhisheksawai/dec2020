package facebookTestCases;

import org.testng.annotations.Test;

public class TestFacebookHomePage {
	
	@Test
	public void tco1_facebook()
	{
		
	}

}
