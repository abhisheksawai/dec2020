package basicJava;

public class ForLoop2 {
	
	
	public static void main(String[] args) {
		
		
		int num;
		int num1;
		for(num=1; num<=4;num++)
		{
			System.out.println("welcome");
			
		}
		
			
	}

}
