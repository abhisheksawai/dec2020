package basicJava;

public class IfCondition3 {
	
	public static void main(String[] args) {
		
		
		int marks = 65;
		
		if(marks > 50) {
			System.out.println("PASS");
			System.out.println("candidate is pass");
		}
		
		else {
			System.out.println("fail");
			System.out.println("else part");
		}
			
		
	}

}
