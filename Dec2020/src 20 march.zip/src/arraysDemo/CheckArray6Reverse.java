package arraysDemo;

public class CheckArray6Reverse {
	
	public static void main(String[] args) {
		
		int a[] = {11,22,33,44,66};
		
		
		for(int i = a.length-1 ; i >=0; i --) 
		{
			System.out.println(a[i]);
		}
		
	}

}
