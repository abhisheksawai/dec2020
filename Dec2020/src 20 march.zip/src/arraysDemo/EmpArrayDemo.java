package arraysDemo;

public class EmpArrayDemo {
	
	int empno;
	String empName;
	
	public EmpArrayDemo(int empno, String empName) {
		super();
		this.empno = empno;
		this.empName = empName;
	}
	
	

}
