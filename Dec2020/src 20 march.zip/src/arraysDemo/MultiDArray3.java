package arraysDemo;

public class MultiDArray3 {
	
	public static void main(String[] args) {
		
		int a[][] = {{1,2,3},{4,45,6},{47,8,9}};
	
		
		
		
		for(int i = 0 ; i < 3; i ++)  // row
		{
			for(int j =0 ; j < 3 ; j ++)  // column
			{
				System.out.println(a[i][j]);
			}
		}
		
		
	}

}
