package inheriTance;

public class Ground {
	
	int run=1234;
	
	public void ground()
	{
		System.out.println("ground");
	}

}
