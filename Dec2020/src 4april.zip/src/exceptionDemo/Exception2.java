package exceptionDemo;

public class Exception2 {
	
	public static void main(String[] args) {
		
		System.out.println("few line in start");  // 400
		
		
		int number = 100/0;
		System.out.println("division is "+number);
		
		System.out.println("few line in end"); // 500
		
	}

}
