package oppsConcept;

public class Employee {
	
	int empid;
	String empname;
	


}
