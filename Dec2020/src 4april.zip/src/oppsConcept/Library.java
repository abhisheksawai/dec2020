package oppsConcept;

public class Library {
	
	private String book;
	
	public void setBookname(String booknm)
	{
		book = booknm;
	}

}
