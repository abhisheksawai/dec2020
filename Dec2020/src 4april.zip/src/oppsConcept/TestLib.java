package oppsConcept;

public class TestLib {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Library l = new Library();
		l.setBookname("istqb");
		
	}

}
