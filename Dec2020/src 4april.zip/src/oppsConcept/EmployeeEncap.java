package oppsConcept;

public class EmployeeEncap {
	
	private String Companyname = "Aamazon";

	public String getCompanyName() {
		return Companyname;
	}
	
	
}
