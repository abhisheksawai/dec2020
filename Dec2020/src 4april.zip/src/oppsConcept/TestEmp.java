package oppsConcept;

public class TestEmp {
	
	public static void main(String[] args) {
		
		EmployeeEncap e = new EmployeeEncap();
		System.out.println(e.getCompanyName());
		
	}

}
