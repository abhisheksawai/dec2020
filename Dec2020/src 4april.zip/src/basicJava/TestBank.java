package basicJava;

public class TestBank  extends doubleparent{
	
	public void p1()
	{
		System.out.println("t1");
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestBank t = new TestBank();
		doubleparent p = new TestBank();
		p.p1();
		
	}

}
