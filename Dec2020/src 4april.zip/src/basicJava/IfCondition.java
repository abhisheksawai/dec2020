package basicJava;

public class IfCondition {
	
	public static void main(String[] args) {
		
		System.out.println("code started here");
		
		int age = 15;
		
		if(age > 18)
		{
			System.out.println("can go for voting");
			System.out.println("if block ");
		}
		
		System.out.println("remaing code");
		
		
	}

}
