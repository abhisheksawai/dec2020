package basicJava;

public class ForLoop {
	
	
	public static void main(String[] args) {
		
		
		int num;
		for(num=1; num<=4;num++)
		{
			System.out.println("welcome");
		}
		
			
	}

}
