package basicJava;

public class IfCondition2 {
	
	public static void main(String[] args) {
		
		int marks = 36;
		if(marks > 50)
		{
			System.out.println("PASS");
		}
		
		else
		{
			System.out.println("fail");
		}
		
		if(marks == 35)
		{
			System.out.println("boundry pass");
		}
	}

}
