package basicJava;

public class Variable4 {
	
	public static void main(String[] args) {
		
		int num1 = 10;
		int num2;
		int sum;  // local variable
		
		num2 = 20;
		num1 = 25;
		
		sum = num1+num2;
		
		System.out.println(sum);		
		
	}

}
