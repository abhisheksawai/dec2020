package basicJava;

public class doubleparent {
	
	public void p1()
	{
		System.out.println("p1");
	}

}
