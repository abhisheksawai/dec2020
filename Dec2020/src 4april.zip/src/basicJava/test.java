package basicJava;

public @interface test {

}
