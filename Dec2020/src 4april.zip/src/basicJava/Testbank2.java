package basicJava;

public class Testbank2 {

	public static void main(String[] args) {
		System.out.println("test");

	}

}
