package collectionDemo;

import java.util.ArrayList;

public class ArrayListDemo12 {
	
	public static void main(String[] args) {
		
		ArrayList a = new ArrayList();  // able to create object
		a.add(10);  //0
		a.add(103);
		a.add(105);
		a.add(104);
		a.add(130);
		a.add(104);
		a.add(106);
		a.add(107);
		a.add(108);
		a.add(109);
		a.add(102);
		System.out.println(a);
		a.remove(10);
		System.out.println(a);
		
		
		
	}

}
