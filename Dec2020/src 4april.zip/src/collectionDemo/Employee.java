package collectionDemo;

public class Employee {
	
	int empno;
	String empname;
	int empid;
	
	
	public Employee(int empno, String empname, int empid) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.empid = empid;
	}
	
	

}
