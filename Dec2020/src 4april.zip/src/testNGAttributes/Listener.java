package testNGAttributes;

import org.testng.ITestListener;
import org.testng.ITestNGListener;

public class Listener implements ITestNGListener {
	
	

}
