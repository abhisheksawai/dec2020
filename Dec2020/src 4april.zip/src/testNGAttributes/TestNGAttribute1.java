package testNGAttributes;

import org.testng.annotations.Test;

public class TestNGAttribute1 {
	
	@Test
	public void tc_01_VerifyHomePage()
	{
		System.out.println("tc o1");
	}

}
