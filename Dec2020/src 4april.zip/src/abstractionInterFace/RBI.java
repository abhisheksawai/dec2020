package abstractionInterFace;

public interface RBI {
	
	public int rateofInterest();

}
