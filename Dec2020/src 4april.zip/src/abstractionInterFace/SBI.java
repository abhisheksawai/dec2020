package abstractionInterFace;

public class SBI implements RBI{

	@Override
	public int rateofInterest() {
		// TODO Auto-generated method stub
		return 8;
	}

}
