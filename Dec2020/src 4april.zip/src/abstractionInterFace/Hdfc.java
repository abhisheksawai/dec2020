package abstractionInterFace;

public interface Hdfc {
	
	public void creditcard();

}
