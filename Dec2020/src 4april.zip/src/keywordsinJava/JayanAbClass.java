package keywordsinJava;

public abstract class JayanAbClass extends JayantaAnotherClass{

}
