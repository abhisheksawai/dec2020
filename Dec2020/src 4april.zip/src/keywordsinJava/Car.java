package keywordsinJava;

public class Car {
	
final public void color()
	{
		System.out.println("silver color");
	}

}
