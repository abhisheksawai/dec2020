package testNGReport;

import org.testng.annotations.Test;

public class TestNGReport1 {
	
	
	@Test
	public void tc01_one()
	{
		System.out.println("one-a");
	}
	
	@Test
	public void tc02_two()
	{
		System.out.println("two=b");
	}
	
	@Test
	public void tc03_three()
	{
		System.out.println("three");
	}

}
