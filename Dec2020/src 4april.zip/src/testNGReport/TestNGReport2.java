package testNGReport;

import org.testng.annotations.Test;

public class TestNGReport2 {
	
	
	@Test
	public void testtc01_one()
	{
		System.out.println("TestNGReport2one-a");
	}
	
	@Test
	public void testtc02_two()
	{
		System.out.println("TestNGReport2two=b");
	}
	
	@Test
	public void testtc03_three()
	{
		System.out.println("TestNGReport2three");
	}

}
