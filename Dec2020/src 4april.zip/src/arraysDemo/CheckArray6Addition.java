package arraysDemo;

public class CheckArray6Addition {
	
	public static void main(String[] args) {
		
		int a[] = {10,2,4,4,21};  // output should be -> 40 is the sum
		// even - 10 2 4 4
		// odd 21
		
		for(int i =0 ; i < a.length; i ++)
		{
			System.out.println(a[i]);
		}
		
	}

}
