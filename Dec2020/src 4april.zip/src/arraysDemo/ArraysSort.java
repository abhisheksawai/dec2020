package arraysDemo;

import java.util.Arrays;

public class ArraysSort {
	
	public static void main(String[] args) {
		
		int a[] = {11,232,33,44,66};
	
		Arrays.sort(a);  // in build method to sort array
		
		for(int i=0; i <a.length ; i ++)
		{
			System.out.println(a[i]);
		}
		
	}
	
	

}
