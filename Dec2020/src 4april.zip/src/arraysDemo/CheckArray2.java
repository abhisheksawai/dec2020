package arraysDemo;

public class CheckArray2 {
	
	public static void main(String[] args) {
		
		int a[] = {11,22,33,44,66};
		
		
		for(int i =0 ; i < 5; i ++)
		{
			System.out.println(a[i]);
		}
		
	}

}
