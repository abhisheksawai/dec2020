package stringDemo;

public class StringReplaceAll {
	
	public static void main(String[] args) {
		
		String s1 ="we with learning Selenium with Java";
		
		String all = s1.replaceAll("w", "x");
		
		System.out.println(all);
		
		
		
	}

}
