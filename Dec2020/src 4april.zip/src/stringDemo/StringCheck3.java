package stringDemo;

public class StringCheck3 {
	
	public static void main(String[] args) {
		
		
		String s = "Harshal";
		System.out.println(s);
		System.out.println(s.concat(" chavan"));
		System.out.println("simplyprinting "+s);
		
		String s1 = "Jayanta";
		s1 = s1.concat("Mandal");
		System.out.println(s1);
		
		
	}

}
