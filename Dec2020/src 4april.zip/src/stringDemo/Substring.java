package stringDemo;

public class Substring {
	
	public static void main(String[] args) {
		
		
		String s0 = "Abhishek Sawai";
						
		System.out.println(s0.substring(11));
		System.out.println(s0.substring(9, 14));
		
		
		
		
		
	}

}
