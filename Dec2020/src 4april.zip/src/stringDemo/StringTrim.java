package stringDemo;

public class StringTrim {
	
	public static void main(String[] args) {
		
		
		String name = "  Abhishek   Sawai   ";
						
		
	System.out.println(name);
		
	System.out.println(name.trim());
		
		
		
	}

}
