package stringDemo;

public class StringCompare2 {
	
	public static void main(String[] args) {
		
		
		String s0 = "HARSHAL";
		String s1 = "Harshal";
		String s2 = new String("Harshal");
		String s3 = "harshal";
		String s4 = "Jayanta";
		
		System.out.println(s0.equals(s3));  
		System.out.println(s0.equalsIgnoreCase(s3));
		
		
		
		
		
	}

}
