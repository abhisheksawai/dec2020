package stringDemo;

public class StringCompare3 {
	
	public static void main(String[] args) {
		
		
		String s0 = "Harshal";
		String s1 = "Harshal";
		String s2 = new String("Harshal");
		
		
		System.out.println(s0 == s1);  // true
		System.out.println(s0 == s2);  // false
		
		
		
		
		
	}

}
