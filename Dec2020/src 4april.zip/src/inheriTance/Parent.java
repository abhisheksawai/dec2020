package inheriTance;

public class Parent extends GrandParent {
	
	public void p1()
	{
		System.out.println("p");
	}
	
	int amount = 10000;
	
	public void property()
	{
		System.out.println("P - 2 bhk to my kid");
	}
	
	public void addition(int num)
	{
		System.out.println(num);
	}
	
	public void marriage()
	{
		System.out.println("P - if go for arrange marriage");
	}

	public static void main(String[] args) {
		
		// 221 will work or 224 here
	}
	
}
