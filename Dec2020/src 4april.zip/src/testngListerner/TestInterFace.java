package testngListerner;

public interface TestInterFace {
	
	public void interfaceone();

}
