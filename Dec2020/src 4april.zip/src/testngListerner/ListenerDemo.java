package testngListerner;

import org.testng.ITestListener;

public class ListenerDemo implements ITestListener {


	
	

}
