package testngListerner;

import org.testng.ITestListener;

public class CheckListener implements ITestListener {

}
