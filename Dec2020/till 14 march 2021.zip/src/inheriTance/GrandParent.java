package inheriTance;

public class GrandParent {
	
	public void house()
	{
		System.out.println("GP - a big Villa");
	}

	public static void main(String[] args) {
		
		
		
	}
	
}
