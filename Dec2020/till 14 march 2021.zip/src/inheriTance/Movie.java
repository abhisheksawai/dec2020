package inheriTance;

public class Movie {
	
	public void release()
	{
		System.out.println("release the movie");
	}

	// main mehtod ?
	
}
