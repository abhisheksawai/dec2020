package inheriTance;

public class ActionMovie extends Movie {
	
	public void fight()
	{
		System.out.println("fight");
	}

	// main mehtod ?
	
}
