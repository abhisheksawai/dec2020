package accessModifiersDemo;

public class EncapDemo {
	
	private String name;
	
	public String getName()
	{
		return name;
	}
	
	public void inserData(String nm)
	{
		name = nm;
	}
	
	

}
