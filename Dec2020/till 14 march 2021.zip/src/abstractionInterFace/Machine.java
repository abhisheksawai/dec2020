package abstractionInterFace;

public interface Machine implements ATMmachine {
	
	public void print();
	public void wash();

}
