package abstractionInterFace;

public class DenaBank implements RBI,WorldBank {
	
	public static void main(String[] args) {
		
		
		
	}

	public int world() {
		return 10;
	}

	public int rateofInterest() {
		return 20;
	}

}
