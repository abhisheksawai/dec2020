package abstractionInterFace;

public interface BankOfAmerica  {
	
	public void boa();

}
