package abstractionInterFace;

public interface WorldBank {
	
	public int world();

}
