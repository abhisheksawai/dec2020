package keywordsinJava;

public class IncrementCheck {
	
	public static void main(String[] args) {
		
		int count = 0 ; // instance variable , when will get memory ? -> when we create object
			System.out.println(count ++);
			System.out.println(count);
		
	}

}
