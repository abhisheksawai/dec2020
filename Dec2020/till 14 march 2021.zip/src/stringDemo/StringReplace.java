package stringDemo;

public class StringReplace {
	
	public static void main(String[] args) {
		
		String s1 ="We with learning Selenium with Java";
		
		String replaceString = s1.replace("with", "replacedwith");
		
		System.out.println(replaceString);
		
		
		
	}

}
