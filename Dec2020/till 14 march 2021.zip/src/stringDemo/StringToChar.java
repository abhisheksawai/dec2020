package stringDemo;

public class StringToChar {
	
	public static void main(String[] args) {
		
		String n1 ="Abhishek";
		
		char[] ch = n1.toCharArray();
		
		for(int i =0; i <ch.length ;  i++)
		{
			System.out.println(ch[i]);
		}
		
		
	}

}
