package stringDemo;

public class StringConcat {
	
	public static void main(String[] args) {
		
		
		String s0 = "Harshal";

		
		System.out.println(s0 + " chavan");
		
		String s = 50+30+"Harshal"+40+60;
		System.out.println(s);
		
		// concat - rod
		// 80Harshal4060 - jaynta | why not 5030Harshal4060 - nishta
		
		
		
		
	}

}
