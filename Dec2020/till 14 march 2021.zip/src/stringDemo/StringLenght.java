package stringDemo;

public class StringLenght {
	
	public static void main(String[] args) {
		
		
		String name = "Abhishek";
						
System.out.println(name.length());
		
		
		
	}

}
