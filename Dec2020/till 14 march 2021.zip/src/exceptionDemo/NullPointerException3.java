package exceptionDemo;

public class NullPointerException3 {
	
	public static void main(String[] args) {
		
		System.out.println("few line in start");
		
		
		String name = null;
		System.out.println(name.length());
		
		
		System.out.println("few line in end");
		
	}

}
