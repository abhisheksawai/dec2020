package basicJava;

public class ClassObject {
	
	int j; // instance variable
	
	
	public static void main(String[] args) {
		
		
		int i; // local variable
	}

}
