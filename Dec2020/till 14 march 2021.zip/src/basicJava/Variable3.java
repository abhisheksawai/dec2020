package basicJava;

public class Variable3 {
	
	public static void main(String[] args) {
		
		System.out.println("end of addition prog begining - line 3");
		System.out.println("we are doing program of addition line 1 ");
		System.out.println("end of addition prog begining - line 0"); // latest line
		
		
		int num1;
		int num2;
		int sum;  // local variable
		
		num2 = 20;
		num1 = 25;
		
		sum = num1+num2;
		System.out.println(sum);		
		
		System.out.println("end of addition prog - line 2 ");
		
	}

}
