package basicJava;

public class IfCondition5 {
	
	public static void main(String[] args) {
		
		
		int marks = 55;
		
		if(marks < 50)
		{
			System.out.println("fail");
		}
		else if(marks >=50 && marks < 60)
		{
			System.out.println("d grade");
			//if --- ur logic 
		}
	
		
		
		
		
		System.out.println("last line of code");
		
		
	}

}
