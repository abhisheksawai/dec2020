package basicJava;

public class IfCondition6 {
	
	public static void main(String[] args) {
		
		
		int age = 17;
		
		if(age > 18)
		{
			System.out.println("can go for marriage");
			
			if(age > 16)
			{
				System.out.println("can go for voting");
			}
			
		}
	
		
		
		
		
		System.out.println("last line of code");
		
		
	}

}
