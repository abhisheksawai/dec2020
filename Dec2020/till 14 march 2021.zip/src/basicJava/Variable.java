package basicJava;

public class Variable {
	
	int addition;
	int no1;
	int no2;
	
	public static void main(String[] args) {
		
		System.out.println("we are doing program of addition ");
		
		int num1;  // primitive data type
		int num2;
		int sum;  // local variable
		
		num1 = 10;
		num2 = 20;
		
		no1 = 30;
		no2 = 40;
		
		sum = num1+num2;
		
		addition = num1+num2;
		
		System.out.println(addition);
		
		
	}
	
	public void m2()
	{
		int m; // local variable to m2 method.
		// other statement 
	}

}
