package basicJava;

public class SwitchStat {
	
	public static void main(String[] args) {
		
		
		int number = 13;
		
		switch(number)
		{
			case 10 : System.out.println("number is 10");
			break;
			
			case 30 : System.out.println("number is 30")/; break;
			
			case 50 : System.out.println("number is 50"); break;
		
			//default : System.out.println("no value present");
		}
		
		
		
		System.out.println("last line");
		
	}

}
