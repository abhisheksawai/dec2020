package basicJava;

public class Variable2 {
	
	public static void main(String[] args) {
		
		System.out.println("we are doing program of addition ");
		
		int num1;
		int num2;
		int sum;  // local variable
		
		num1 = 100;
		num1=120;
		num1=30;
		num1 = 10;
		num2 = 20;
		
		num1 = 25;
		
		sum = num1+num2;
		System.out.println(sum);		
		
		num1=200;
		
		System.out.println("end of addition prog ");
		
	}

}
