package testNGAttributes;

import org.testng.annotations.Test;

public class TestNGAttribute2 {
	
	@Test(description="Verify facebook homepage getting displayed")
	public void tc_01_VerifyHomePage()
	{
		System.out.println("tc o1");
	}

}
