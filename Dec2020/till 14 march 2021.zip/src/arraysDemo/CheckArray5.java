package arraysDemo;

public class CheckArray5 {
	
	public static void main(String[] args) {
		
		int a[] = {11,232,33,44,66};
		//int lenofarray = a.length;
		//System.out.println("lengh of array is "+lenofarray);
		
		for(int temp : a)  // for each loop
		{
			// line of code
			System.out.println("temp is "+temp);
			
		}
		
	}

}
