package arraysDemo;

public class PassArrayInMethod {

	
	public static void main(String[] args) {
		
		int a[] = {10,34,5,6,18};
		
		
		
	}
	
}
