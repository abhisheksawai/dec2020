package collectionDemo;

public class P {
	
	int num;
	String name;
	
	
	


	public void p1()
	{
		System.out.println("p1");
	}

	public void p2()
	{
		System.out.println("p2");
	}
	
}
