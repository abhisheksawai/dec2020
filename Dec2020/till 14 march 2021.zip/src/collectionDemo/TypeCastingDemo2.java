package collectionDemo;

public class TypeCastingDemo2 {
	
	public static void main(String[] args) {
		
		char s = 'Y';
		System.out.println("printing charachter here "+s);
		
		int num = 10;
		System.out.println("printing num her "+num);
		
		int x = 'a';  // 1 byte to 2 byte upcasting ./ widening
		System.out.println(x);  // compiler is respo | implicit type cast
		
	}

}
