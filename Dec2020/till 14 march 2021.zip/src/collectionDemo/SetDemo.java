package collectionDemo;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	
	public static void main(String[] args) {
		
	//	Set s1 = new HashSet();
	//	HashSet s2 = new HashSet();
	//	Set s3 = new Set(); // not possible
	//	HashSet s4 = new Set(); // not possible
		
		// s1.which methods ?  s1-hashset methods arun | s1- set and hashset methods - harshal
		// s2.which methods ?  s2-hashset methods arun | s2- only hashset methods
	}

}
