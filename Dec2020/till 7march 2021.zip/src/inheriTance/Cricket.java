package inheriTance;

public class Cricket {
	
	int run=123;
	
	public Cricket()
	{
		System.out.println("Cricket - const");
	}
	
	public void c1()
	{
		System.out.println("c1");
	}

}
