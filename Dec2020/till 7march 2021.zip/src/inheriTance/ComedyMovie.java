package inheriTance;

public class ComedyMovie extends Movie{
	
	public void smile()
	{
		System.out.println("smile");
	}

	// main mehtod ?
	
}
