package accessModifiersDemo;

public class TestEncp {
	
	public static void main(String[] args) {
		
		EncapDemo ed = new EncapDemo();
		ed.inserData("Divyani");
	//	System.out.println(ed.getName());
		
		String divString = ed.getName();
		System.out.println("div string-> "+divString);
		
	//	System.out.println(ed.name);
		
		
		
	}

}
