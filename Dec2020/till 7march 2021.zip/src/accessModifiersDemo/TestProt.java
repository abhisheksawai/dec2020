package accessModifiersDemo;

public class TestProt {
	
	public static void main(String[] args) {
		
		ProtectedCheck pc = new  ProtectedCheck();
		pc.m5();
		
	}

}
