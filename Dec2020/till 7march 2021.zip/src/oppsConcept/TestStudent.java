package oppsConcept;

public class TestStudent {
	
public static void main(String[] args) {
		
		Student s1 = new Student(); // creating object
		//System.out.println(s1);
		
			
	//	System.out.println(s1.rollno);
		//System.out.println(s1.name);
		
		s1.rollno = 101;
		s1.name = "Arun";
		
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		
		Employee e2 = new Employee();
		e2.empid = 112;
		e2.empname = "raghvendra";
		
		System.out.println(e2.empid);
		System.out.println(e2.empname);
		
		
	}

}
