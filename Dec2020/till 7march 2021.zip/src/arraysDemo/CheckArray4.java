package arraysDemo;

public class CheckArray4 {
	
	public static void main(String[] args) {
		
		int a[] = {11,232,33,44,66};
		//int lenofarray = a.length;
		//System.out.println("lengh of array is "+lenofarray);
		
		for(int i =0 ; i < a.length; i ++)
		{
			System.out.println(a[i]);
		}
		
	}

}
