package keywordsinJava;

public class ParentBlock {
	
	{
		System.out.println("i0-6");
	}
	
	static
	{
		System.out.println("s0");
	}
	
	public ParentBlock()
	{
		System.out.println("p0");
	}
	
	{
		System.out.println("i0-20");
	}

}
