package keywordsinJava;

public class Nexa extends Car {

	public void color1()
	{
		System.out.println("black");
	}
	
	public static void main(String[] args) {
		
		Nexa n = new Nexa();
		n.color();
		
	}
	
}
