package keywordsinJava;

public class JayantaAnotherClass {
	
	public void m1()
	{
		System.out.println("impletedmented method");
	}

}
