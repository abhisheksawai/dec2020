package keywordsinJava;

public class TestJayantaAbstract extends  JayantaAbstract {

	@Override
	public void ma() {
		// TODO Auto-generated method stub
		
		System.out.println("ma");
		
	}
	
	public static void main(String[] args) {
		TestJayantaAbstract tj = new TestJayantaAbstract();
		
		tj.m1();
	}

}
