package keywordsinJava;

public class JayantaClass extends JayantaAbstract {

	@Override
	public void j1() {
		// TODO Auto-generated method stub
		System.out.println("test");  
		
	}
	
	public static void main(String[] args) {
		
		JayantaClass j = new JayantaClass();
		j.j1();
		
	}

}
