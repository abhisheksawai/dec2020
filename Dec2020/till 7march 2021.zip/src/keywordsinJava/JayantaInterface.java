package keywordsinJava;

public interface JayantaInterface {
	
	public void j1();
	
	public static void m5()
	{
		System.out.println("m5");
	}

}
