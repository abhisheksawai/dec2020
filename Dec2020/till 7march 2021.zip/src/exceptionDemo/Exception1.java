package exceptionDemo;

public class Exception1 {
	
	public static void main(String[] args) {
		
		System.out.println("few line in start");
		
		
		int number = 100/2;
		System.out.println("division is "+number);
		
		
		System.out.println("few line in end");
		
	}

}
