package basicJava;

public class Continue2 {
	
	
	public static void main(String[] args) {
		
		
		int i,j;
		for(i=1; i<4;i++)  // outer loop 3 times
		{
				for ( j  = 1; j < 4; j++) { // inner loop
				
				System.out.println("i is "+i+" i is "+j);
				
				}
		}
		
			
	}

}
