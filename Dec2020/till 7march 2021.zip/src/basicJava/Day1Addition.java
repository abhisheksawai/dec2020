package basicJava;

public class Day1Addition {
	
	public static void main(String[] args) {
		
		System.out.println("we are doing program of addition ");
		
		int num1;
		int num2;
		int sum;
		
		num1 = 10;
		num2 = 20;
		
		sum = num1+num2;
		System.out.println(sum);
		
		System.out.println("Addition is --->"+sum);
		
		System.out.println("Answer is "+sum+" is total sum");
		
		
		
	}

}
