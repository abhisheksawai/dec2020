package basicJava;

public class Operator2 {
	
	public static void main(String[] args) {
		
		int num1=101;
		int num2=50;
		
		System.out.println(num1+num2);
		System.out.println(num1-num2);
		System.out.println(num1*num2);
		System.out.println(num1/num2);
		
		System.out.println(num1%num2);
		
	}

}
