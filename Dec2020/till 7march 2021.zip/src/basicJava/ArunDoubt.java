package basicJava;

public class ArunDoubt {
	
	
	public static void main(String[] args) {
		
		
		int num;
		int luckybumber = 0 ;
		for(num=1; num<=7;num++)
		{
			if(num == 5)
			{
				luckybumber = num;
			}
			
			if(luckybumber >= 5)
			{
				System.out.println(num);
			}
			
			
			}
		}
		
			
	}

