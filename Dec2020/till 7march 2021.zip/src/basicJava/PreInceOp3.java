package basicJava;

public class PreInceOp3 {
	
	public static void main(String[] args) {
		
		
		int num1=10;
		int num2 ;
		num2 = num1++ + num1++;
		System.out.println(num2);
		
		
		//System.out.println(num2 = num1++ + num1++);
	
		
		
		//	System.out.println(num1++ + num1++);

	
	}

}
