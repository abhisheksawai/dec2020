package collectionDemo;

import java.util.ArrayList;

public class ArrayListGenerics {
	
	public static void main(String[] args) {
		
		ArrayList<String> al = new ArrayList<>();
		
		// ArrayList al = new ArrayList();
		
		al.add("Abhishek");
		al.add("Divyani");
		al.add("arun");
		al.add('Y');
		al.add(10);
		
		System.out.println(al);
		
		
	}

}
