package stringDemo;

public class StringCheck {
	
	public static void main(String[] args) {
		
		String n1 ="Abhishek0";
		String n0 ="Abhishek1";
		String n2 = new String ("Abhishek2");
		String n3 = new String ("Abhishek3");
		
		System.out.println(n0);
		System.out.println(n1);
		System.out.println(n2);
		System.out.println(n3);
		
		
		
	}

}
