package stringDemo;

public class StringConcat2 {
	
	public static void main(String[] args) {
		
		
		String s0 = "Harshal";
		String s1 = " Chavan";
		
		System.out.println(s0 + s1);
		
		System.out.println(s0.concat(s1));
		String s3 = s0.concat(s1);
		System.out.println(s3);
		
		
		
		
		
	}

}
