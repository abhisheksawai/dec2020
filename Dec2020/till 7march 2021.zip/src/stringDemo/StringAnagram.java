package stringDemo;

public class StringAnagram {
	
	public static void main(String[] args) {
		
		
		String s1 = "arc";
		String s2 = "car";
		
		// your logic
		
		System.out.println("Yes anagram | not angram");
		
						

		
		
		
	}

}
