package stringDemo;

public class StringCheck2 {
	
	public static void main(String[] args) {
		
		
		String s = "Harshal";
		System.out.println(s);
		System.out.println(s.concat(" chavan"));
		System.out.println("simplyprinting "+s);
		
		
	}

}
