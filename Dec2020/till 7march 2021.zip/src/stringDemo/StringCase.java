package stringDemo;

public class StringCase {
	
	public static void main(String[] args) {
		
		
		String name = "Abhishek Sawai";
						
		
		System.out.println(name.toLowerCase());
		
		System.out.println(name.toUpperCase());
		
		
		
		
	}

}
