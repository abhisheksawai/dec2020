package abstractionInterFace;

public interface Icici {
	
	public void creditcard();

}
