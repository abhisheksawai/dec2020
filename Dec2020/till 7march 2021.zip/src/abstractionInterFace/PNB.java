package abstractionInterFace;

public class PNB implements RBI{

	@Override
	public int rateofInterest() {
		// TODO Auto-generated method stub
		return 9;
	}

}
