package abstractionInterFace;

public abstract class Car {
	
	abstract void startEngine();	

}
