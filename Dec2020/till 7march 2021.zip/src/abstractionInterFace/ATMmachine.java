package abstractionInterFace;

public abstract class ATMmachine {
	
	abstract void withdraw();	// abstract method
	
	public void Statement()  // non abstract method
	{
		System.out.println("email the statement");		
	}

}
